﻿using Microsoft.Xna.Framework;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework.Graphics;
using System;
using JungleMimicItemsMod.Items.Weapons;
using JungleMimicItemsMod.Projectiles;

namespace JungleMimicItemsMod.Buffs
{
    public class JungleMimic_Summon_Buff : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Jungle Mimic");
            Description.SetDefault("The Jungle Mimic will fight for you");
            Main.buffNoTimeDisplay[Type] = true;
            Main.buffNoSave[Type] = true;
        }

        public override void Update(Player player, ref int buffIndex)
        {
            if (player.ownedProjectileCounts[mod.ProjectileType("JungleMimic_Summon")] > 0)
            {
                player.buffTime[buffIndex] = 2;
            }
        }
    }
}