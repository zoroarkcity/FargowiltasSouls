using Terraria.ModLoader;

namespace JungleMimicItemsMod
{
	public class JungleMimicItemsMod : Mod
	{
		public JungleMimicItemsMod()
		{
		}
	}
}